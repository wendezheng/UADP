//
//  ContentViewController.m
//  UADP
//
//  Created by hello world on 14-11-11.
//  Copyright (c) 2014年 csu. All rights reserved.
//

#import "ContentViewController.h"
#import "CommentViewController.h"
#import "AdvertismentViewController.h"
#import "SBJson.h"
#import "SBJsonParser.h"
@interface ContentViewController ()
@end

@implementation ContentViewController

@synthesize articleID = _articleID;
@synthesize webViewContent = _webViewContent;
@synthesize commentTabBar = _commentTabBar;
@synthesize timer = _timer;
@synthesize articleData = _articleData;
@synthesize aPath;
/*
@synthesize myScrollView,pageControl;
@synthesize imageArray = _imageArray;
@synthesize myTimer  = _myTimer;
@synthesize control = _control;
@synthesize advURL = _advURL;
//@synthesize mainScrollView = _mainScrollView;
-(NSMutableArray *)advURL
{
    if (!_advURL) {
        _advURL = [[NSMutableArray alloc]init];
    }
    return  _advURL;
}

- (void)initAdvURL
{
    [self.advURL addObject:@"http://my.its.csu.edu.cn/Home/Default"];
    [self.advURL addObject:@"http://my.its.csu.edu.cn/Home/Default"];
    [self.advURL addObject:@"http://my.its.csu.edu.cn/Home/Default"];
    [self.advURL addObject:@"http://my.its.csu.edu.cn/Home/Default"];
    [self.advURL addObject:@"http://my.its.csu.edu.cn/Home/Default"];

}

-(void)initArray
{
    _imageArray = [[NSMutableArray alloc]init];
    [self.imageArray addObject:[UIImage imageNamed:@"category-1.png"]];
    [self.imageArray addObject:[UIImage imageNamed:@"category-2.png"]];
    [self.imageArray addObject:[UIImage imageNamed:@"category-3.png"]];
    [self.imageArray addObject:[UIImage imageNamed:@"category-4.png"]];
    [self.imageArray addObject:[UIImage imageNamed:@"category-5.png"]];
    //存放图片的数组
    
}
 */

-(NSMutableData *)articleData
{
    if (!_articleData) {
        _articleData = [[NSMutableData alloc]init];
    }
    return _articleData;
}
 static int second = 0;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    //[self getArticle:@"tt" articleid:@"75"];
    //NSLog(@"------%d------",[self.articleID integerValue]);
    //[self searchDB:[self.articleID integerValue]];
    self.articleData = (NSMutableData*)[self.aPath dataUsingEncoding:NSUTF8StringEncoding];
    [self viewinit];
    
    
}
-(void)searchDB:(int)articleid
{
    
    [self viewinit];
}

-(void)viewinit
{
    
    // CGRect frame=CGRectMake(0, self.navigationController.navigationBar.frame.origin.y+self.navigationController.navigationBar.frame.size.height+80, 320, 460);
    //[self.webViewContent setFrame:CGRectMake(0,142,320,377)];
    
    
    //[self.view setBackgroundColor:[UIColor grayColor]];
    //    NSURL *url= [NSURL URLWithString:_strURL];
    //    NSURLRequest *req=[NSURLRequest requestWithURL:url];
    //    [_webViewContent loadRequest:req];
    NSMutableData *advdata = (NSMutableData *)[@"                                              <html><head> </head><body><div></div>" dataUsingEncoding:NSUTF8StringEncoding];
    NSLog(@"%@+-+",advdata);
    //NSData *data = [NSData dataWithContentsOfFile:_strURL];
   // NSLog(@"%@+-+4-+",data);
    [advdata appendData:_articleData];
    NSLog(@"%@+-+",advdata);
    NSData *taildata = [@"</body></html>" dataUsingEncoding:NSUTF8StringEncoding];
    [advdata appendData:taildata];
    NSArray *paths= NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docdir=[paths objectAtIndex:0];
    NSURL *baseurl = [NSURL fileURLWithPath:docdir];
    [_webViewContent loadData:advdata MIMEType:@"text/html" textEncodingName:@"utf-8" baseURL:baseurl];
    [_webViewContent setOpaque:NO];
    //[_webViewContent stringByEvaluatingJavaScriptFromString:@"document.getElementsByTagName('body')[0].style.background='#222222'"];

    
    
    
    [_commentTabBar setDelegate:self];
    
    //[self StartTimer];
    //[_timer setFireDate:[NSDate distantPast]];
    second = 0;
    NSLog(@"ViewDidLoad");
    self.numLove=0;
    
    NSLog(@"ViewDidLoad--%f",self.navigationController.navigationBar.frame.origin.y);
    
    //[self initArray];
    
    //[self configScrollView];
    
    self.webViewContent= [[UIWebView alloc]initWithFrame:CGRectMake(0,142,320,377)];
    
    // [self initAdvURL];

}

/*
-(void)configScrollView
{
    
    //初始化UIScrollView，设置相关属性，均可在storyBoard中设置
    //self.webViewContent.frame =CGRectMake(0, self.navigationController.navigationBar.frame.origin.y+self.navigationController.navigationBar.frame.size.height+80, 320, 460);
    CGRect frame=CGRectMake(0, self.navigationController.navigationBar.frame.origin.y+self.navigationController.navigationBar.frame.size.height, 320, 80);
    self.myScrollView = [[UIScrollView alloc]initWithFrame:frame];    //scrollView的大小
    self.myScrollView.backgroundColor=[UIColor blueColor];
    self.myScrollView.pagingEnabled=YES;//以页为单位滑动，即自动到下一页的开始边界
    self.myScrollView.showsVerticalScrollIndicator=NO;
    self.myScrollView.showsHorizontalScrollIndicator=NO;//隐藏垂直和水平显示条
    
    
    
    self.myScrollView.delegate=self;
    UIImageView *firstView=[[UIImageView alloc] initWithImage:[_imageArray lastObject]];
    CGFloat Width=self.myScrollView.frame.size.width;
    CGFloat Height=self.myScrollView.frame.size.height;
    firstView.frame=CGRectMake(0, 0, Width, Height);
    [self.myScrollView addSubview:firstView];
    //set the last as the first
    
    for (int i=0; i<[_imageArray count]; i++) {
        UIImageView *subViews=[[UIImageView alloc] initWithImage:[_imageArray objectAtIndex:i]];
        subViews.frame=CGRectMake(Width*(i+1), 0, Width, Height);
        
 ///////////
        self.control = [[UIControl alloc]initWithFrame: subViews.frame];
        [self.control addTarget:self action:@selector(controlClick:) forControlEvents:UIControlEventTouchUpInside];
        [self.control addSubview:subViews];
        self.control.tag = i;
        [self.control setUserInteractionEnabled:YES];
        [self.myScrollView addSubview:self.control];
        
        [self.myScrollView addSubview: subViews];
    }
    
    UIImageView *lastView=[[UIImageView alloc] initWithImage:[_imageArray objectAtIndex:0]];
    lastView.frame=CGRectMake(Width*(_imageArray.count+1), 0, Width, Height);
    [self.myScrollView addSubview:lastView];
    //set the first as the last
    
    [self.myScrollView setContentSize:CGSizeMake(Width*(_imageArray.count+2), Height)];
    [self.view addSubview:self.myScrollView];
    [self.myScrollView scrollRectToVisible:CGRectMake(Width, 0, Width, Height) animated:NO];
    //show the real first image,not the first in the scrollView
    
    //[self.webViewContent addSubview:self.myScrollView];
     //设置pageControl的位置，及相关属性，可选
     CGRect pageControlFrame=CGRectMake(70, self.myScrollView.frame.origin.y+self.myScrollView.frame.size.height/2, 78, 36);
     self.pageControl=[[UIPageControl alloc]initWithFrame:pageControlFrame];
     
     [self.pageControl setBounds:CGRectMake(0, 0, 16*(self.pageControl.numberOfPages-1), 16)];//设置pageControl中点的间距为16
     [self.pageControl.layer setCornerRadius:8];//设置圆角
    
    self.pageControl.numberOfPages=_imageArray.count;
    //self.pageControl.backgroundColor=[UIColor blueColor];//背景
    self.pageControl.currentPage=0;
    self.pageControl.enabled=YES;
    [self.view addSubview:self.pageControl];
    //[self.pageControl addTarget:self action:@selector(pageTurn:)forControlEvents:UIControlEventValueChanged];
    
    self.myTimer=[NSTimer scheduledTimerWithTimeInterval:2.0f target:self selector:@selector(scrollToNextPage:) userInfo:nil repeats:YES];
    
    
     //self.webViewContent= [[UIWebView alloc]initWithFrame:CGRectMake(0,162,320,377)];

}





#pragma UIScrollView delegate
-(void)scrollToNextPage:(id)sender
{
    int pageNum=self.pageControl.currentPage;
    CGSize viewSize=self.myScrollView.frame.size;
    CGRect rect=CGRectMake((pageNum+2)*viewSize.width, 0, viewSize.width, viewSize.height);
    [self.myScrollView scrollRectToVisible:rect animated:NO];
    pageNum++;
    if (pageNum==_imageArray.count) {
        CGRect newRect=CGRectMake(viewSize.width, 0, viewSize.width, viewSize.height);
        [self.myScrollView scrollRectToVisible:newRect animated:NO];
    }
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat pageWidth=self.myScrollView.frame.size.width;
    int currentPage=floor((self.myScrollView.contentOffset.x-pageWidth/2)/pageWidth)+1;
    if (currentPage==0) {
        self.pageControl.currentPage=_imageArray.count-1;
    }else if(currentPage==_imageArray.count+1){
        self.pageControl.currentPage=0;
    }
    self.pageControl.currentPage=currentPage-1;
    
}
-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    [self.myTimer invalidate];
}
-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    self.myTimer=[NSTimer scheduledTimerWithTimeInterval:2.0f target:self selector:@selector(scrollToNextPage:) userInfo:nil repeats:YES];
}
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    CGFloat pageWidth=self.myScrollView.frame.size.width;
    CGFloat pageHeigth=self.myScrollView.frame.size.height;
    int currentPage=floor((self.myScrollView.contentOffset.x-pageWidth/2)/pageWidth)+1;
    NSLog(@"the current offset==%f",self.myScrollView.contentOffset.x);
    NSLog(@"the current page==%d",currentPage);
    
    if (currentPage==0) {
        [self.myScrollView scrollRectToVisible:CGRectMake(pageWidth*_imageArray.count, 0, pageWidth, pageHeigth) animated:NO];
        self.pageControl.currentPage=_imageArray.count-1;
        NSLog(@"pageControl currentPage==%d",self.pageControl.currentPage);
        NSLog(@"the last image");
        return;
    }else  if(currentPage==[_imageArray count]+1){
        [self.myScrollView scrollRectToVisible:CGRectMake(pageWidth, 0, pageWidth, pageHeigth) animated:NO];
        self.pageControl.currentPage=0;
        NSLog(@"pageControl currentPage==%d",self.pageControl.currentPage);
        NSLog(@"the first image");
        return;
    }
    self.pageControl.currentPage=currentPage-1;
    NSLog(@"pageControl currentPage==%d",self.pageControl.currentPage);
    
}

-(void)controlClick:(UITapGestureRecognizer*)sender
{
    NSLog(@"ianmmdmf%d",[(UIView*)sender tag]);
    AdvertismentViewController *advViewControl = [[AdvertismentViewController alloc]init];
    advViewControl.advURL = [_advURL objectAtIndex:[(UIView*)sender tag]];
     NSLog(@"%@",advViewControl.advURL);
    [self.navigationController pushViewController:advViewControl animated:YES];
    
    
}
*/
//网页上的链接用safari打开
-(BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    if (navigationType==UIWebViewNavigationTypeLinkClicked) {
        NSURL *url = [request URL];
        if ([[UIApplication sharedApplication]canOpenURL:url]) {
            [[UIApplication sharedApplication]openURL:url];
             NSLog(@"O");
        }
         NSLog(@"NO");
        return  NO;
       
    }
     NSLog(@"y");
    return YES;
}

-(void)webViewDidStartLoad:(UIWebView *)webView
{
    NSLog(@"webViewDidStartLoad");
}
-(void)webViewDidFinishLoad:(UIWebView *)webView
{
    NSLog(@"webViewDidFinishLoad");
}

-(void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    NSLog(@"didFailLoadWithError");
}

-(void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item
{
    switch (item.tag) {
        case 0:
            NSLog(@"item%ld",(long)item.tag);
            break;
        case 1:
            NSLog(@"item%ld",(long)item.tag);
            break;
        case 2:
            NSLog(@"item%ld",(long)item.tag);
            break;
        default:
            break;
    }
    if (item.tag==1) {
        CommentViewController * commentPage = [[CommentViewController alloc]init];
        [self.navigationController pushViewController:commentPage animated:YES];
    }
    if (item.tag==0) {
        [item setTitle:[NSString stringWithFormat:@"%d",++self.numLove]];
    }
    NSLog(@"string");
    
}


-(void)StartTimer
{
  _timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(timerAdvanced:) userInfo:nil repeats:YES];
    //[timer setFireDate:[NSDate distantPast]];
    NSLog(@"st");
   
}


-(void)timerAdvanced:(NSTimer*)timer
{
    
    //static int second = 0;
    //if (second==0) {
       // [timer invalidate];
        //[self StartTimer];
    //}
    
//    if (second>=6) {
//        second=0;
//        //[_timer invalidate];
//        //[timer invalidate];
//    }
    second++;
    NSLog(@"%d",second);
    
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewDidDisappear:(BOOL)animated
{
    NSLog(@"%@maxReadedTime---%d",_articleID,[[[NSUserDefaults standardUserDefaults]objectForKey:_articleID]intValue]);
    //保存最长阅读时间
    
    //[[NSUserDefaults standardUserDefaults]setBool:YES forKey:_strURL];
   // if ([[NSUserDefaults standardUserDefaults]boolForKey:_strURL]) {
        if ([[[NSUserDefaults standardUserDefaults]objectForKey:_articleID]intValue]<second)
        {
            [[NSUserDefaults standardUserDefaults]setValue:[NSNumber numberWithInt:second] forKey:_articleID];
            [[NSUserDefaults standardUserDefaults]synchronize];
            
            NSLog(@"%d",second);
        }
   // }
   
    //second = 0;
    [_timer invalidate];
    
    NSLog(@"%@maxReadedTime---%@",_articleID,[[NSUserDefaults standardUserDefaults]objectForKey:_articleID]);
}

-(void)viewWillAppear:(BOOL)animated
{
    NSLog(@"viewWillAppear---");
    [self StartTimer];
}
-(void)viewDidAppear:(BOOL)animated
{
     NSLog(@"viewDidAppear---");
    
}




- (void)getArticle:(NSString *)rusername articleid:(NSString *)articleid
{
    // Establish the request
    //NSString *body = [NSString stringWithFormat:@"username=%@&articleid=%@",rusername,articleid];
    NSString *jsons = [NSString stringWithFormat:@"{\"id\":\"%@\"}",articleid];
    NSString *body = [NSString stringWithFormat:@"jsons=%@",jsons];
    NSLog(@"%@",body);
    NSString *baseurl = [NSString stringWithFormat:@"%@?",[self getArticleContentIP]];  //chuliapp地址
    NSLog(@"baseurl = %@", baseurl);
    
	NSURL *url = [NSURL URLWithString:baseurl];
	NSMutableURLRequest *urlRequest = [NSMutableURLRequest requestWithURL:url];
    [urlRequest addValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    //[urlRequest addValue:bodyLength forHTTPHeaderField:@"Content-Length"];
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[body dataUsingEncoding:NSUTF8StringEncoding]];
    NSLog(@"urlrequest = %@", urlRequest);
    NSURLConnection *getContentConnetion= [[NSURLConnection alloc] initWithRequest: urlRequest delegate: self];
    
}


- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    
    [self.articleData appendData:data];
	//NSString *rsp = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
	//NSLog(@"connection    2  Received data = %@  ", rsp);
    //self.articleData=[rsp dataUsingEncoding:NSUTF8StringEncoding];
    
}
-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
     NSLog(@"connection done!");
    NSString *rsp = [[NSString alloc] initWithBytes:[self.articleData mutableBytes]length:[self.articleData length] encoding:NSUTF8StringEncoding];
    NSLog(@"%@",rsp);
    if ([[rsp substringToIndex:1]isEqualToString:@"<"]) {
        NSLog(@"<<<<<<<<<<<<<<<<<<<<<<<<<");
        return;
    }
	//NSLog(@"connection    2  Received data = %@  ", [rsp JSONValue]);
    NSArray * nsa = [[NSArray alloc]init];
    nsa = [rsp JSONValue];
    NSLog(@"%@",nsa);
    NSDictionary *result = [nsa objectAtIndex:0];

    NSString * htmlpath = [result objectForKey:@"path"];
    NSLog(@"connection    2  Received data = %@  ", htmlpath);
    [self.articleData setLength:0];
    self.articleData = (NSMutableData*)[htmlpath dataUsingEncoding:NSUTF8StringEncoding];
    [self viewinit];
}
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
	NSHTTPURLResponse *resp = (NSHTTPURLResponse *)response;
	NSLog(@"Response statusCode:    %lu", (long)resp.statusCode);
    //[self.articleData setLength:0];
}



-(void) connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    NSLog(@"connection error!");
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"温馨提示"
                                                        message:@"连接错误"
                                                       delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
    [alertView show];
    
}


-(NSString*)getArticleContentIP
{
    NSString *contentIP=nil,*serverIp=nil;
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    
    NSString *serverioPlist = [[paths objectAtIndex:0]stringByAppendingPathComponent:@"serverIP.plist"];
    if ([[NSFileManager defaultManager]fileExistsAtPath:serverioPlist]) {
        NSDictionary *dict = [[NSDictionary alloc]initWithContentsOfFile:serverioPlist];
        for (NSString *category in dict)
        {
            NSLog(@"%@",category);
            NSLog(@"--++---%@",[dict valueForKey:category]);
            if ([category isEqualToString:@"serverip"])
                serverIp=[dict valueForKey:category];
            if ([category isEqualToString:@"contentIP"])
                contentIP=[dict valueForKey:category];
            
        }
    }
    else
    {
        NSString *plpath = [[NSBundle mainBundle]pathForResource:@"serverIP" ofType:@"plist"];
        NSDictionary *dict = [[NSDictionary alloc]initWithContentsOfFile:plpath];
        for (NSString *category in dict)
        {
            NSLog(@"%@",category);
            if ([category isEqualToString:@"serverip"])
                serverIp=[dict valueForKey:category];
            if ([category isEqualToString:@"contentIP"])
            {contentIP=[dict valueForKey:category];
                NSLog(@"--+-+--%@",[dict valueForKey:category]);
            }
        }
        
    }
    //return contentIP;
    return [NSString stringWithFormat:@"%@%@",serverIp,contentIP];
}





@end
