//
//  MainViewController.m
//  UADP
//
//  Created by hello world on 14-11-11.
//  Copyright (c) 2014年 csu. All rights reserved.
//

#import "MainViewController.h"
#import "CategoryViewController.h"
#import "SBJson.h"
#import "SBJsonParser.h"
#import "CSUAppDelegate.h"
#import "ShowMessageViewController.h"
@interface MainViewController ()

@end

@implementation MainViewController
@synthesize listOfApp = _listOfApp;
@synthesize scrollView =_scrollView;
@synthesize allData = _allData;
@synthesize listOfAppID = _listOfAppID;
@synthesize listOfAppName = _listOfAppName;
-(NSMutableArray *)listOfAppName
{
    if (!_listOfAppName) {
        _listOfAppName = [[NSMutableArray alloc]init];
    }
    return _listOfAppName;
}
-(NSMutableArray *)listOfAppID
{
    if (!_listOfAppID) {
        _listOfAppID = [[NSMutableArray alloc]init];
    }
    return _listOfAppID;
}

- (IBAction)cancel:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}
-(NSMutableArray *)listOfApp
{
    if (!_listOfApp) {
        _listOfApp = [[NSMutableArray alloc]init];
    }
    return _listOfApp;
}
-(NSMutableData *)allData
{
    if (!_allData) {
        _allData = [[NSMutableData alloc]init];
    }
    return _allData;
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    CSUAppDelegate *csuapp = [[UIApplication sharedApplication] delegate];
    NSLog(@"%@",[NSString stringWithFormat:@"%@拥有的APP",csuapp.username]);
    //[self getAllApp:[NSString stringWithFormat:@"%d",csuapp.deptid]];
    [self setTitle:[NSString stringWithFormat:@"%@",csuapp.username]];
    [self getAllApp:csuapp.deptname];
    
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)generateButtons:(NSInteger)count
{
    //int count =arc4random()%50+4;
    
    self.scrollView.frame = CGRectMake(0, 0, 320, 560);
    [self.scrollView setContentSize:CGSizeMake(320, self.view.frame.size.height/8*count)];
     NSLog(@"%d",count);
    
    int n = 10;
    int heit=self.scrollView.frame.size.height,widh=self.scrollView.frame.size.width;
    NSLog(@"%f",self.view.frame.size.height);
    for (int i=1; i<=count; i++) {

        CGRect frame = CGRectMake(widh/2*((i+1)%2)+2.5, /*heit/((n+1)*2)+*/heit/(n/2)*((i-1)/2)+20, widh/2-5, heit/n*2-5/*+30*/);
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.backgroundColor = [UIColor brownColor];
        [button setTitle:[_listOfAppName objectAtIndex:i-1]/*[NSString stringWithFormat:@"app--%d",i]*/ forState:UIControlStateNormal];
        [button setTag:i-1];
        //[button setBackgroundImage:[UIImage imageNamed:@"category-5"] forState:UIControlStateNormal];
        [button addTarget:self action:@selector(runButtonActions:) forControlEvents:UIControlEventTouchUpInside];
        //NSLog(@"%f---%f", self.view.frame.size.height, self.view.frame.origin.y);
        button.frame = frame;
        //[self.view addSubview:button];
        [self.scrollView addSubview:button];
        
    }


}

- (void)runButtonActions:(id)sender
{
    // Configure new view & push it with custom |pushViewController:| method
    CategoryViewController *CategoryVC= [[CategoryViewController alloc]init];
     [CategoryVC setTitle:[_listOfAppName objectAtIndex:[sender tag]]];
    CategoryVC.appID = [[_listOfAppID objectAtIndex:[sender tag]] integerValue];
    CategoryVC.appName = [_listOfAppName objectAtIndex:[sender tag]];
    //CategoryVC.listOfCategory = [self.listOfApp objectAtIndex:[sender tag]];
    
//    for (int i=0; i<[CategoryVC.listOfCategory count]; i++) {
//        NSDictionary *category=[CategoryVC.listOfCategory objectAtIndex:i];
//        NSString *modelName = [category objectForKey:@"modelName"];
//        [CategoryVC.listOfCategoryName addObject:modelName];
//        
//        NSArray *articleid = [category objectForKey:@"articleId"];
//        NSArray *articleName = [category objectForKey:@"articleName"];
//        if ([articleid count]>0 && [articleName count]>0) {
//            [CategoryVC.listOfAllArticleID addObject:articleid];
//            [CategoryVC.listOfAllArticleName addObject:articleName];
//        }
//        
//    }
    
    
    
    [self.navigationController pushViewController:CategoryVC animated:YES];
    
}






- (void)getAllApp:(NSString *)deptid
{
    // Establish the request
//    NSString *body = [NSString stringWithFormat:@"username=%@",rusername];
    NSLog(@"++++++++++++%@",deptid);
  //  NSString *jsons = [NSString stringWithFormat:@"{\"id\":\"22\"}"];
    NSString *jsons = [NSString stringWithFormat:@"{\"owner\":\"%@\"}",deptid];
    NSString *body = [NSString stringWithFormat:@"jsons=%@",jsons];
    NSString *baseurl = [NSString stringWithFormat:@"%@?",[self getAllAppIP]];  //chuliapp地址
    NSLog(@"baseurl = %@", baseurl);
    
	NSURL *url = [NSURL URLWithString:baseurl];
	NSMutableURLRequest *urlRequest = [NSMutableURLRequest requestWithURL:url];
    [urlRequest addValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    //[urlRequest addValue:bodyLength forHTTPHeaderField:@"Content-Length"];
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[body dataUsingEncoding:NSUTF8StringEncoding]];
    NSLog(@"urlrequest = %@", urlRequest);
    NSURLConnection *getAppConnetion= [[NSURLConnection alloc] initWithRequest: urlRequest delegate: self];
    
}


- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [self.allData appendData:data];
    
    
	NSString *rsp = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
	NSLog(@"connection    2  Received data = %@  ", rsp);
    
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
	NSHTTPURLResponse *resp = (NSHTTPURLResponse *)response;
    self.statecode =(long)resp.statusCode;
	NSLog(@"Response statusCode:    %lu", (long)resp.statusCode);
}

-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSLog(@"connection done!");
    NSString *rsp = [[NSString alloc] initWithBytes:[self.allData mutableBytes] length:[self.allData length] encoding: NSUTF8StringEncoding];

    if ([rsp isEqualToString:@"{\"result\":true}"]) {
        return;
    }
    if (self.statecode==404 || self.statecode==500) {
        NSLog(@"<<<<<<<<<<<<<<<<<<<<<<<<<");
        //查本地数据库显示
        if ([rsp isEqualToString:@"{\"result\":true}"]) {
            return;
        }
        
        
        
        
        //[self searchDB];
        
        return;
    }
    
	NSLog(@"connection    2  Received data = %@  ", rsp);
    CSUAppDelegate *csuapp = [[UIApplication sharedApplication]delegate];
    
//    NSString *deleteSql = @"delete from app;";
//    [csuapp.dboperate updateDB:deleteSql];
    NSMutableArray *jsonsappid = [[NSMutableArray alloc]init];
    NSArray * dataArray= [[NSArray alloc]init];
    
    dataArray = [rsp JSONValue];
    int count = [dataArray count];
    NSLog(@"count=%d",count);
    for (int i=0; i<count; i++) {
        NSDictionary *result = [dataArray objectAtIndex:i];
        NSString * appName = [result objectForKey:@"name"];
        NSLog(@"connection    2  Received data = %@  ", appName);
        [self.listOfAppName addObject:appName];
        int appID = [[result objectForKey:@"id"] integerValue];
        NSLog(@"connection    23333333  Received data = %d  ", appID);
        [self.listOfAppID addObject:[NSNumber numberWithInt:appID]];
        NSArray * appdata = [result objectForKey:@"data"];
        
        NSLog(@"connection    2  Received data = %@  ", appdata);
        [self.listOfApp addObject:appdata];
        
        NSString *sbumitter = [result objectForKey:@"submitter"];
        NSString *sbumittime = [result objectForKey:@"submittime"];
        NSString *aplogo = [result objectForKey:@"logo"];
        NSString *apowner = [result objectForKey:@"owner"];
        
        NSString *deptcode = [result objectForKey:@"deptcode"];
        
        NSString *lastediter = [result objectForKey:@"lastediter"];
        NSString *lastedittime = [result objectForKey:@"lastedittime"];
        NSString *aplabel = [result objectForKey:@"label"];
        NSString *apexplain = [result objectForKey:@"explain"];
        NSString *apstate = [result objectForKey:@"state"];
        
        NSString *sql=[NSString stringWithFormat:@"insert or replace into app(appid,appname,appdata,appsubmitter,appsubmittime,applogo,appowner,applastediter,applastedittime,applabel,appexplain,appstate,deptcode)values(%d,'%@','%@','%@','%@','%@','%@','%@','%@','%@','%@','%@','%@');",appID,appName,appdata,sbumitter,sbumittime,aplogo,apowner,lastediter,lastedittime,aplabel,apexplain,apstate,deptcode];
        NSLog(@"%@",sql);
        [csuapp.dboperate updateDB:sql];
        
        //APP---LOGO   TODO
        
        
        NSDictionary *dictionary =[[NSMutableDictionary alloc]init];
        [dictionary setValue:[NSNumber numberWithInt:appID] forKey:@"appid"];
        [jsonsappid addObject:dictionary];
        
    }
    
    
    
    [self.allData setLength:0];

    
    [self generateButtons:count];
    
    
    NSDictionary *root=[[NSMutableDictionary alloc]init];
    [root setValue:jsonsappid forKey:@"jsonsappid"];
    NSUserDefaults *userDefaults=[NSUserDefaults standardUserDefaults];
    [root setValue:@"e0f67e4c26dcb54bf050029475058cc5d31f2321fcc8b070f8015ff3f747b432"/*[userDefaults objectForKey:@"DeviceTokenStringKEY"]*/ forKey:@"devicetoken"];
    [root setValue:[NSNumber numberWithInt:csuapp.uid] forKey:@"userid"];
    
    SBJsonWriter *sendconfirm = [[SBJsonWriter alloc] init];
    NSString *sendvalue = [sendconfirm stringWithObject:root];
    
    NSLog(@"json---------------%@",sendvalue);
    
    [self sendDevicetoken:sendvalue];
    

    
}

-(void) connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    NSLog(@"connection error!");
    //查本地数据库显示
    [self searchDB];
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"温馨提示"
                                                        message:@"连接错误"
                                                       delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
    [alertView show];
    
}


-(NSString*)getAllAppIP
{
    NSString *AllAppIP=nil,*serverIp=nil;
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    
    NSString *serverioPlist = [[paths objectAtIndex:0]stringByAppendingPathComponent:@"serverIP.plist"];
    if ([[NSFileManager defaultManager]fileExistsAtPath:serverioPlist]) {
        NSDictionary *dict = [[NSDictionary alloc]initWithContentsOfFile:serverioPlist];
        for (NSString *category in dict)
        {
            NSLog(@"%@",category);
            NSLog(@"--++---%@",[dict valueForKey:category]);
            if ([category isEqualToString:@"serverip"])
                serverIp=[dict valueForKey:category];
            if ([category isEqualToString:@"allAppIP"])
                AllAppIP=[dict valueForKey:category];
            
        }
    }
    else
    {
        NSString *plpath = [[NSBundle mainBundle]pathForResource:@"serverIP" ofType:@"plist"];
        NSDictionary *dict = [[NSDictionary alloc]initWithContentsOfFile:plpath];
        for (NSString *category in dict)
        {
            NSLog(@"%@",category);
            if ([category isEqualToString:@"serverip"])
                serverIp=[dict valueForKey:category];
            if ([category isEqualToString:@"allAppIP"])
            {AllAppIP=[dict valueForKey:category];
                NSLog(@"--+-+--%@",[dict valueForKey:category]);
            }
        }
        
    }
    //return AllAppIP;
    return [NSString stringWithFormat:@"%@%@",serverIp,AllAppIP];
}

-(void)searchDB
{
    CSUAppDelegate *appDelegate = [UIApplication sharedApplication].delegate;
    //DBOperation *dboperate = [[DBOperation alloc]init];
    NSLog(@"---%@",appDelegate.username);
    // order by scheduledate desc,scheduletime desc
   // NSString *sql = [NSString stringWithFormat:@"select * from app where appowner=%d and appstate=0;",appDelegate.deptid];
    //根据当前用户查询所拥有的app还没加条件
    NSString *sql = [NSString stringWithFormat:@"select * from app where appowner =%@;",appDelegate.deptname];
    NSLog(@"55555555+++++++++++++++++++++%@",sql );
    

    NSLog(@"%ld",(long)[appDelegate.dboperate getCount:sql]);
    
    NSMutableArray *jsonsappid=[[NSMutableArray alloc]init];
    
    NSMutableArray *temp=[[NSMutableArray alloc]init];
    temp =[appDelegate.dboperate getAllapp:sql];
    
    for (int i=0; i<[temp count]; i++) {
        [self.listOfAppID addObject:[[temp objectAtIndex:i]objectForKey:@"appid"]];
        [self.listOfAppName addObject:[[temp objectAtIndex:i] objectForKey:@"appname"]];
        //[self.isreadMuti addObject:[[temp objectAtIndex:i] objectForKey:@"isread"]];
        // [self.dateAndtime addObject:[NSString stringWithFormat:@"%@ %@",[[temp objectAtIndex:i] objectForKey:@"scheduledate"],[[temp objectAtIndex:i] objectForKey:@"scheduletime"]]];
        NSDictionary *dictionary =[[NSMutableDictionary alloc]init];
        [dictionary setValue:[[temp objectAtIndex:i]objectForKey:@"appid"] forKey:@"appid"];
        [jsonsappid addObject:dictionary];
    }
    
    
    [self generateButtons:[self.listOfAppName count]];
    
    NSDictionary *root=[[NSMutableDictionary alloc]init];
    [root setValue:jsonsappid forKey:@"jsonsappid"];
    NSUserDefaults *userDefaults=[NSUserDefaults standardUserDefaults];
    [root setValue:/*@"e0f67e4c26dcb54bf050029475058cc5d31f2321fcc8b070f8015ff3f747b432"*/[userDefaults objectForKey:@"DeviceTokenStringKEY"] forKey:@"devicetoken"];
    [root setValue:[NSNumber numberWithInt:appDelegate.uid] forKey:@"userid"];
    
    SBJsonWriter *sendconfirm = [[SBJsonWriter alloc] init];
    NSString *sendvalue = [sendconfirm stringWithObject:root];
    
    NSLog(@"json---------------%@",sendvalue);
    
    [self sendDevicetoken:sendvalue];
    
    
    
}

-(void)sendDevicetoken:(NSString *)json
{
     NSString *body = [NSString stringWithFormat:@"jsons=%@",json];
    NSString *baseurl = [NSString stringWithFormat:@"%@?",[self getSaveTokenIP]];  //chuliapp地址
    NSLog(@"baseurl = %@", baseurl);
    
	NSURL *url = [NSURL URLWithString:baseurl];
	NSMutableURLRequest *urlRequest = [NSMutableURLRequest requestWithURL:url];
    [urlRequest addValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    //[urlRequest addValue:bodyLength forHTTPHeaderField:@"Content-Length"];
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[body dataUsingEncoding:NSUTF8StringEncoding]];
    NSLog(@"urlrequest = %@", urlRequest);
    NSURLConnection *sendDevicetokenConnetion= [[NSURLConnection alloc] initWithRequest: urlRequest delegate: self];
}
-(NSString*)getSaveTokenIP
{
    NSString *SaveTokenIP=nil,*serverIp=nil;
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    
    NSString *serverioPlist = [[paths objectAtIndex:0]stringByAppendingPathComponent:@"serverIP.plist"];
    if ([[NSFileManager defaultManager]fileExistsAtPath:serverioPlist]) {
        NSDictionary *dict = [[NSDictionary alloc]initWithContentsOfFile:serverioPlist];
        for (NSString *category in dict)
        {
            NSLog(@"%@",category);
            NSLog(@"--++---%@",[dict valueForKey:category]);
            if ([category isEqualToString:@"serverip"])
                serverIp=[dict valueForKey:category];
            if ([category isEqualToString:@"saveTokenIP"])
                SaveTokenIP=[dict valueForKey:category];
            
        }
    }
    else
    {
        NSString *plpath = [[NSBundle mainBundle]pathForResource:@"serverIP" ofType:@"plist"];
        NSDictionary *dict = [[NSDictionary alloc]initWithContentsOfFile:plpath];
        for (NSString *category in dict)
        {
            NSLog(@"%@",category);
            if ([category isEqualToString:@"serverip"])
                serverIp=[dict valueForKey:category];
            if ([category isEqualToString:@"saveTokenIP"])
            {SaveTokenIP=[dict valueForKey:category];
                NSLog(@"--+-+--%@",[dict valueForKey:category]);
            }
        }
        
    }
    //return SaveTokenIP;
    
    return [NSString stringWithFormat:@"%@%@",serverIp,SaveTokenIP];
    
}

@end
