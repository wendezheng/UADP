//
//  ContentViewController.h
//  UADP
//
//  Created by hello world on 14-11-11.
//  Copyright (c) 2014年 csu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ContentViewController : UIViewController<UIWebViewDelegate,UITabBarDelegate,UIScrollViewDelegate,UIImagePickerControllerDelegate>
@property (strong, nonatomic) IBOutlet UIWebView *webViewContent;
@property(nonatomic,strong) NSString *articleID;
@property(strong,nonatomic) NSMutableData *articleData;
//@property(strong,nonatomic) IBOutlet UITabBar * tabbar;
@property (strong, nonatomic) IBOutlet UITabBar *commentTabBar;
@property (strong,nonatomic) NSTimer *timer;
@property int numLove;
@property(nonatomic,strong) NSString *aPath;
/*
@property (strong, nonatomic) IBOutlet UIScrollView *myScrollView;
@property (strong, nonatomic) IBOutlet UIPageControl *pageControl;
@property(strong,nonatomic)  NSMutableArray *imageArray;//存放图片
@property(strong,nonatomic)  NSTimer *myTimer;//定时器
@property(strong,nonatomic)  NSMutableArray *advURL;//广告对应的链接
@property(strong,nonatomic) UIControl *control;
*/
//@property (strong, nonatomic) IBOutlet UIScrollView *mainScrollView;

@end
